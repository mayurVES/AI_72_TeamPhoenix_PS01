# Text-to-Speech Application

A Python application that converts text to speech using ElevenLabs API, providing multiple voice options.

## Features

- Convert text to high-quality speech with multiple voice options
- User-friendly web interface
- Command-line interface for direct usage
- MP3 output files
- Support for multiple languages

## Installation

1. Clone this repository:
```bash
git clone <repository-url>
cd text-to-speech-app
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create a `.env` file in the project root directory and add your ElevenLabs API key:
```
ELEVENLABS_API_KEY=your_api_key_here
```

You can get an API key by signing up at [ElevenLabs](https://elevenlabs.io/).

## Usage

### Web Interface

1. Start the Flask web server:
```bash
python app.py
```

2. Open a web browser and go to http://127.0.0.1:5000/

3. Enter your text, select a voice, and click "Generate Speech"

### Command-Line Interface

The application also includes a command-line interface for direct usage:

```bash
# List available voices
python tts_cli.py --list

# Convert text to speech
python tts_cli.py --text "Hello, this is a test." --voice <voice_id> --output output.mp3

# Convert text from a file
python tts_cli.py --file input.txt --voice <voice_id> --output output.mp3
```

## Parameters

- `--text`: Text to convert to speech
- `--file`: Text file to convert to speech
- `--voice`: Voice ID to use (required, use `--list` to see available voices)
- `--output`: Output file path (default: output.mp3)

## License

MIT 