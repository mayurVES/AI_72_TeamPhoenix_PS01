import os
import sys
import argparse
from elevenlabs import generate, set_api_key, voices, Voice
from elevenlabs.api import Models
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set ElevenLabs API key
api_key = os.getenv("ELEVENLABS_API_KEY")
if not api_key:
    print("Error: No API key found. Please set ELEVENLABS_API_KEY in .env file")
    sys.exit(1)
set_api_key(api_key)

def list_voices():
    """List all available voices with their IDs"""
    all_voices = voices()
    print("\nAvailable Voices:")
    print("----------------")
    for voice in all_voices:
        print(f"ID: {voice.voice_id}")
        print(f"Name: {voice.name}")
        print(f"Description: {voice.description}")
        print("----------------")
    return all_voices

def generate_speech(text, voice_id, stability=0.5, clarity=0.75, output_file=None):
    """Generate speech from text using specified voice and parameters"""
    # Generate audio with the simplified API call
    print(f"Generating speech with voice ID: {voice_id}")
    audio = generate(
        text=text,
        voice=voice_id,
        model="eleven_multilingual_v2"
    )
    
    # Save audio to file
    if not output_file:
        output_file = "output.mp3"
    
    with open(output_file, 'wb') as f:
        f.write(audio)
    
    print(f"Speech saved to: {output_file}")
    return output_file

def main():
    parser = argparse.ArgumentParser(description="Text-to-speech CLI using ElevenLabs API")
    parser.add_argument("--text", type=str, help="Text to convert to speech")
    parser.add_argument("--file", type=str, help="Text file to convert to speech")
    parser.add_argument("--voice", type=str, help="Voice ID to use")
    parser.add_argument("--list", action="store_true", help="List available voices")
    parser.add_argument("--stability", type=float, default=0.5, help="Voice stability (0.0-1.0)")
    parser.add_argument("--clarity", type=float, default=0.75, help="Voice clarity/similarity boost (0.0-1.0)")
    parser.add_argument("--output", type=str, default="output.mp3", help="Output file path")
    
    args = parser.parse_args()
    
    # List voices and exit
    if args.list:
        list_voices()
        sys.exit(0)
    
    # Validate input
    if not args.text and not args.file:
        print("Error: Either --text or --file must be provided")
        parser.print_help()
        sys.exit(1)
    
    if not args.voice:
        print("Error: --voice must be provided")
        print("Use --list to see available voices")
        sys.exit(1)
    
    # Get text from file if provided
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                text = f.read()
        except Exception as e:
            print(f"Error reading file: {e}")
            sys.exit(1)
    else:
        text = args.text
    
    # Generate speech
    generate_speech(
        text=text,
        voice_id=args.voice,
        stability=args.stability,
        clarity=args.clarity,
        output_file=args.output
    )

if __name__ == "__main__":
    main() 