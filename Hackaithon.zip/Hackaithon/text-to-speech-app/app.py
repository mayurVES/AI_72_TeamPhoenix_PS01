import os
import time
from flask import Flask, render_template, request, send_file, jsonify
from elevenlabs import generate, set_api_key, voices, Voice
from elevenlabs.api import Models
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set ElevenLabs API key
api_key = os.getenv("ELEVENLABS_API_KEY")
if not api_key:
    raise ValueError("No API key found. Please set ELEVENLABS_API_KEY in .env file")
set_api_key(api_key)

app = Flask(__name__)

# Create output directory if it doesn't exist
os.makedirs("static/output", exist_ok=True)

@app.route('/')
def index():
    # Get available voices from ElevenLabs
    available_voices = voices()
    return render_template('index.html', voices=available_voices)

@app.route('/text-to-speech', methods=['POST'])
def text_to_speech():
    try:
        # Get data from form
        text = request.form.get('text')
        voice_id = request.form.get('voice')
        stability = float(request.form.get('stability', 0.5))
        clarity = float(request.form.get('clarity', 0.75))
        
        if not text:
            return jsonify({"error": "No text provided"}), 400
        
        # Generate audio with the current API format
        audio = generate(
            text=text,
            voice=voice_id,
            model="eleven_multilingual_v2"
        )
        
        # Save audio to file
        timestamp = int(time.time())
        output_path = f"static/output/speech_{timestamp}.mp3"
        
        with open(output_path, 'wb') as f:
            f.write(audio)
        
        return jsonify({
            "success": True,
            "audio_path": output_path
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True) 